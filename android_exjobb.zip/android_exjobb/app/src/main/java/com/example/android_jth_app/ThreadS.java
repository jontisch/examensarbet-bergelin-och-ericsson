package com.example.android_jth_app;

import android.app.Application;
import android.bluetooth.BluetoothSocket;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;



public class ThreadS extends Application {
    public static ConnectedThread myThread;


    public static class ConnectedThread<mHandler> extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException ignored) {
            }
            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void write(byte[] message) {

            //byte[] msgBuffer = message.getBytes();
            try {
                mmOutStream.write( message );
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //listen to incoming data
        //runs on thread
        public void run() {
            StringBuilder str = new StringBuilder();
            int  buff = 0;
            while (true) {

                try {
                    buff = mmInStream.read();
                    if(buff != '\n'){
                        str.append( (char) buff );
                    }
                    else {
                        str.append( '\n' );
                        Log.d("LOG", "RX:  "+str);
                        SendA.mhandler.obtainMessage( 1, str.toString() ).sendToTarget();
                        str = new StringBuilder();
                    }
                } catch (IOException ignored) {

                };

            }
        }

    }
}

