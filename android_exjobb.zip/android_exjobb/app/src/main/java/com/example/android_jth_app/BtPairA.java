package com.example.android_jth_app;


import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;



public class BtPairA extends AppCompatActivity {


    private static final int PERMISSION_ACCESS_COARSE_LOCATION = 1;
    private static final long SCAN_PERIOD = 30000;

    public BluetoothManager bm;
    public BluetoothAdapter btAdapter = null;
    public static BluetoothSocket socket = null;
    public boolean bt_state;
    public  List<String> s_pair = new ArrayList<String>();
    public  List<BluetoothDevice> pair = new ArrayList<BluetoothDevice>();
    public  List<String> s_scan = new ArrayList<String>();
    public  List<BluetoothDevice> scan = new ArrayList<BluetoothDevice>();
    public StringBuilder sb = new StringBuilder();

    public static BluetoothDevice device;
    public static BluetoothGatt bleGatt;
    public static BluetoothGattCharacteristic bleRX, bleTX;
    public BroadcastReceiver broadcastReceiver;

    public ListView pairedview;
    public ListView scannedview;
    public View btpair;
    public Handler mhandler = new Handler();

    public static boolean timeToRead = false;

    //UUID FOR BR/EDR SPP PROFILE
    public static final UUID SPP_UUID = UUID.fromString( "00001101-0000-1000-8000-00805F9B34FB" );
    //UUID DESCRIPTOR CONFIG
    public static final UUID DESCRIPTOR_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    //UUID CUSTOM
    public static final UUID CUSTOM_SPP_RX_UUID = UUID.fromString("ed24d0cf-8cff-2c91-724a-4376455eb332");
    //UUID CUSTOM
    public static final UUID CUSTOM_SPP_TX_UUID = UUID.fromString("afaf1dc2-87ab-63bf-8149-9e5cb684b286");
    //UUID FOR CUSTOM GATT SERVICE
    public static final UUID CUSTOM_SPP_UUID = UUID.fromString("073f6f5c-f1c6-c686-7b43-069756746941");


    protected void onCreate(@Nullable Bundle savedinstancestate) {
        super.onCreate( savedinstancestate );
        setContentView( R.layout.activity_scan_pair );
        Log.d( "LOG", "PAIR ACTIVITY" );

        pairedview = (ListView) findViewById( R.id.paired_bt );
        scannedview = (ListView) findViewById( R.id.scanned_bt );
        btpair = (View) findViewById(R.id.btpair);
        bm = (BluetoothManager) getSystemService( Context.BLUETOOTH_SERVICE );
        bt_state = getIntent().getExtras().getBoolean( "BT_STATE" );
        btAdapter = bm.getAdapter();
        pairedview.setAdapter( new ArrayAdapter<String>( this,
                android.R.layout.simple_list_item_1, s_pair
        ) );
        scannedview.setAdapter( new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,s_scan));
        checkBT();
        checkLocationP();
        checkBT_tech();
        asksdcardP();
        checkPairedDevices();
        scanDevices();
        connectPairedDevice();
        pairScannedDevice();


    }

    //BLE CALLBACK
    public BluetoothGattCallback gattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.d("LOG", "CONNECTING BLE: "+ status +" "+newState);
            super.onConnectionStateChange(gatt, status, newState);
            if(newState == BluetoothProfile.STATE_CONNECTED) {
                Log.d("LOG", "CONNECTED BLE:" + gatt.getDevice().getName()+" STATUS: " + status );
                bleGatt.discoverServices();

            }
            else if(newState == BluetoothProfile.STATE_DISCONNECTED)
            {
                Log.d("LOG", "DISCONNECTED BLE");
                bleGatt.disconnect();
                bleGatt.close();
            }
        }
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            for(BluetoothGattService service : bleGatt.getServices())
            {
                Log.d("LOG", "SERVICE: " +service.getUuid().toString());
                for (BluetoothGattCharacteristic characteristic : service.getCharacteristics())
                {
                    Log.d("LOG", "CHARACTERISTICS: "+ characteristic.getUuid().toString());
                    for ( BluetoothGattDescriptor descriptor : characteristic.getDescriptors())
                    {
                        try
                        {
                            Log.d("LOG", "DESCRIPTOR: "+descriptor.getValue().toString() +" "+descriptor.getUuid().toString());
                        }catch(Exception ignored)
                        {
                        }
                    }
                }
                //UTVECKLINGKORT UUID
                if(service.getUuid().toString().equalsIgnoreCase(CUSTOM_SPP_UUID.toString()))
                {
                    bleGatt.setPreferredPhy(BluetoothDevice.PHY_LE_2M,BluetoothDevice.PHY_LE_2M,BluetoothDevice.PHY_OPTION_NO_PREFERRED);
                    bleGatt.requestConnectionPriority( BluetoothGatt.CONNECTION_PRIORITY_HIGH );
                    bleGatt.requestMtu(512);
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    Log.d("LOG", "onServicesDiscovered:  EVB FOUND");
                    bleRX = service.getCharacteristic(CUSTOM_SPP_RX_UUID);
                    bleTX = service.getCharacteristic(CUSTOM_SPP_TX_UUID);
                    for(BluetoothGattDescriptor bluetoothGattDescriptor : bleRX.getDescriptors())
                    {
                        bluetoothGattDescriptor = bleRX.getDescriptor(DESCRIPTOR_CONFIG_UUID);
                        bluetoothGattDescriptor.setValue(bluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        bleGatt.writeDescriptor(bluetoothGattDescriptor);
                    }
                    bleGatt.setCharacteristicNotification(bleRX, true);
                    bleGatt.setCharacteristicNotification(bleTX, true);
                    Intent intent1 = new Intent( getApplicationContext(), SendA.class );

                    intent1.putExtra("BT_STATE2",bt_state);
                    startActivity( intent1 );
                    finish();

                }

            }
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);

        }

        @Override
        public void onPhyRead(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyRead(gatt, txPhy, rxPhy, status);

        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic, int status) {

            super.onCharacteristicRead(gatt, characteristic, status);
                    runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String rx_string = new String(characteristic.getStringValue( 0 ));
                    sb.append(rx_string);
                    SendA.terminalv.setText(sb);
                    SendA.scrollView.fullScroll( View.FOCUS_DOWN );
                    SendA.READING = false;
                    if(SendA.autosend)
                    {
                        SendA.writeToFile( SendA.terminalv.getText().toString(),getApplicationContext() );
                    }
                }
            });
        }
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            //Log.d( "LOG", "onCharacteristicChanged: " );
            if(characteristic == bleRX)
            {
                timeToRead = true;
                SendA.SENDING=false;
                //Log.d("LOG", "onCharacteristicChanged: RX CHAR "+ bleRX.getStringValue(0));

            }
            if(characteristic == bleTX)
            {
                //Log.d("LOG", "onCharacteristicChanged:################# ");
            }

        }
        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            if(status==gatt.GATT_SUCCESS )
            {
                SendA.SENDING=false;
                //Log.d( "LOG", "onCharacteristicWrite: STATUS: "+status );
            }
            else
            {
                Log.d("LOG", "onCharacteristicWrite: PACKETLOSS STATUS: "+status);
            }
        }
    };
    //START SCAN FOR DEVICES
    private void scanDevices() {
        Log.d("LOG", "scanDevices");
        Toast.makeText(getApplicationContext(), "START SCANNING FOR DEVICES", Toast.LENGTH_SHORT).show();
        btAdapter.startDiscovery();
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, final Intent intent) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                Log.d( "LOG", "onReceive: "+ device.getName() + " TYPE: "+device.getType() );
                if(!bt_state)
                {
                    if(device.getType() == 2 || device.getType() == 3)
                    {
                        scan.add(device);
                        s_scan.add(device.getName() +"\n "+ device.getAddress()+"\n TYPE:"+ device.getType());
                    }
                }
                else
                {
                    if(device.getType() == 1|| device.getType() == 3)
                    {
                        scan.add(device);
                        s_scan.add(device.getName() +"\n "+ device.getAddress()+"\n TYPE:"+ device.getType());
                    }

                }

                        scannedview.invalidateViews();
                        pairedview.invalidateViews();
                    }
                });
            }
        };
        IntentFilter ifilter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.registerReceiver(broadcastReceiver, ifilter);
        mhandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(btAdapter.isDiscovering())
                {
                    Log.d("LOG", "STOP SCAN");
                    Toast.makeText(getApplicationContext(), "SCANNING STOPPED", Toast.LENGTH_SHORT).show();
                    btAdapter.cancelDiscovery();
                }
            }
        }, SCAN_PERIOD);

    }
    //CONNECT DEVICE
    private void connectPairedDevice(){
        pairedview.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MainActivity.vibrate(100);
                try
                {
                    if(btAdapter.isDiscovering())
                    {
                        Log.d("LOG", "STOP SCAN");
                        Toast.makeText(getApplicationContext(), "SCANNING STOPPED", Toast.LENGTH_SHORT).show();
                        btAdapter.cancelDiscovery();
                        unregisterReceiver( broadcastReceiver );
                    }
                }catch( Exception e)
                {
                    e.printStackTrace();
                }
                BluetoothDevice device = btAdapter.getRemoteDevice( pair.get( position ).getAddress());
                int bt_type = device.getType();
                if(bt_type == 1|| bt_type ==3)//BR/EDR
                {
                    if(bt_state)
                    {
                        try {
                            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            Log.d( "LOG", "TRY CONNECT BR/EDR "+device.getName() );
                            socket.connect();
                            int type = socket.getConnectionType();
                            int mxrx = socket.getMaxReceivePacketSize();
                            int mxtx = socket.getMaxTransmitPacketSize();
                            //SendA.txtfile.concat("maxtx: "+ mxrx+"maxrx:  "+mxtx+" STATUS RCOMM1/SCO2/L2CAP3: "+type);
                            ThreadS.myThread = new ThreadS.ConnectedThread(socket);
                            ThreadS.myThread.start();
                            Intent intent1 = new Intent( getApplicationContext(), SendA.class );
                            intent1.putExtra("BT_STATE2",bt_state);
                            startActivity( intent1 );
                            Log.d("LOG", "CONNECTED "+device.getName()+ "\n Connection type: RFCOMM =1 SCO=2 L2CAP=3: "+type+" \n "+"MAXPRX: "+mxrx+" MAXPTX "+mxtx);
                            finish();
                        }catch (Exception e){
                            e.printStackTrace();
                            try {
                                Log.d( "LOG", "FAILED TO CONNECT BR/EDR "+ device.getName() );
                                socket = null;
                            } catch (Exception ee) {
                                ee.printStackTrace();
                            }
                        }
                    }

                }
                if(bt_type == 2 || bt_type == 3)//BLE
                {
                    if(!bt_state)
                    {
                        if(bt_type==3)
                        {
                            try
                            {
                                Log.d( "LOG", "TRY CONNECT BLE AUTO"+device.getName() );
                                bleGatt = device.connectGatt(getApplicationContext(), false, gattCallback,BluetoothDevice.TRANSPORT_LE);
                            }catch(Exception e)
                            {
                                e.printStackTrace();
                            }

                        }
                        else {
                            try
                            {
                                Log.d( "LOG", "TRY CONNECT BLE "+device.getName() );
                                bleGatt = device.connectGatt(getApplicationContext(), false, gattCallback);
                            }catch(Exception e)
                            {
                                e.printStackTrace();
                            }
                        }


                    }

                }
            }
        } );
    }
    //PAIR DEVICE
    private void pairScannedDevice(){
        scannedview.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                MainActivity.vibrate(100);
                try
                {
                    if(btAdapter.isDiscovering())
                    {
                        Log.d("LOG", "STOP SCAN");
                        Toast.makeText(getApplicationContext(), "SCANNING STOPPED", Toast.LENGTH_SHORT).show();
                        btAdapter.cancelDiscovery();
                        unregisterReceiver( broadcastReceiver );
                    }
                }catch( Exception e)
                {
                    e.printStackTrace();
                }
                device = btAdapter.getRemoteDevice( scan.get( position ).getAddress());
                int bt_type = device.getType();
                if(bt_type == 1 || bt_type == 3)//BR/EDR
                {
                    if(bt_state)
                    {
                        //PAIR BR/EDR
                        try
                        {
                            if(!pair.contains( device ))
                            {
                                Log.d( "LOG", "TRY PAIR CLASSIC" );
                                if(device.createBond())
                                {
                                    Log.d("LOG", "PAIR CLASSIC");
                                    pair.add( device );
                                    s_pair.add(device.getName() +"\n "+ device.getAddress()+"\n TYPE:"+ device.getType());
                                    runOnUiThread( new Runnable() {
                                        @Override
                                        public void run() {
                                            pairedview.invalidateViews();
                                        }
                                    } );

                                }
                            }
                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }

                    }

                }
                if(bt_type == 2 || bt_type == 3)//BLE
                {
                    if(!bt_state)
                    {
                        //PAIR BLE
                        try
                        {
                            Log.d("LOG", "PAIR BLE");
                            if(!pair.contains( device ))
                            {
                                pair.add( device );
                                s_pair.add(device.getName() +"\n "+ device.getAddress()+"\n TYPE:"+ device.getType());
                                runOnUiThread( new Runnable() {
                                    @Override
                                    public void run() {
                                        pairedview.invalidateViews();
                                    }
                                } );
                            }
                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                }
            }
        } );
    }
    //CHECK AND ASK FOR LOCATION PERMISSION
    private void checkLocationP() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.ACCESS_COARSE_LOCATION },
                    PERMISSION_ACCESS_COARSE_LOCATION);
        }
    }
    //ASK FOR STORAGE PERMISSION
    private void asksdcardP() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.WRITE_EXTERNAL_STORAGE },
                    1);
        }
    }
    //CHECK PAIRED DEVICE FROM MOBILE DEVICE
    private void checkPairedDevices() {
        Set<BluetoothDevice> pairedDevices = btAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            // There are paired devices. Get the name and address of each paired device.
            for (BluetoothDevice device : pairedDevices) {
                int type = device.getType();
                if(bt_state && type == 1 )//br/edr
                {
                    unpairDevice( device );
                    //pair.add( device);
                    //s_pair.add(device.getName() +"\n "+ device.getAddress()+"\n "+ device.getType());
                }
                if(!bt_state && (type == 2 ))//ble and dual
                {
                    unpairDevice( device );
                    //pair.add( device);
                    //s_pair.add(device.getName() +"\n "+ device.getAddress()+"\n "+ device.getType());
                }
                if((type == 3 ))//ble and dual
                {
                    unpairDevice( device );
                    //pair.add( device);
                    //s_pair.add(device.getName() +"\n "+ device.getAddress()+"\n "+ device.getType());
                }
                Log.d("LOG", "checkPairedDevices: "+device.getName() +" "+ device.getType());
            }
        }
    }
    //CHECK SUPPORTED BLUETOOTH TECH
    private void checkBT_tech(){
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            //BLE NOT SUPPORTED
            Toast.makeText(this, "Bluetooth low energy is not available", Toast.LENGTH_LONG).show();
        }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)) {
            //BTC NOT SUPPORTED
            Toast.makeText(this, "Bluetooth classic  is not available", Toast.LENGTH_LONG).show();
        }
    }
    //CHECK BT SUPPORT AND CHECK IF BT IS ACTIVATED
    private void checkBT() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if (btAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
        }
        else {
            if (!btAdapter.isEnabled()) {
                //ask user to turn on bluetooth
                Intent enableBtIntent = new Intent( BluetoothAdapter.ACTION_REQUEST_ENABLE );
                startActivityForResult( enableBtIntent, 1 );
                finish();
            }
        }
    }
    public static void close() {
        if (bleGatt == null) {
            return;
        }
        bleGatt.close();
        bleGatt = null;
    }
    public static void unpairDevice(BluetoothDevice device) {
        try {
            Method m = device.getClass().getMethod("removeBond", (Class[]) null);
            m.invoke(device, (Object[]) null);
        } catch (Exception e) {
            Log.e("LOG", e.getMessage());
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        scan.clear();
        s_scan.clear();
        pair.clear();
        s_pair.clear();

        try{
            unregisterReceiver(broadcastReceiver);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        btAdapter.cancelDiscovery();
        close();
        unpairDevice( device );
        finish();
    }
}
