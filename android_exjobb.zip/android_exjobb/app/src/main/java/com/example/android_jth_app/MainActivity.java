package com.example.android_jth_app;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    public static Vibrator vibrate;
    private boolean bt_state =false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vibrate = (Vibrator) getSystemService( VIBRATOR_SERVICE );

    }
    public void low_energy_clicked(View view)
    {
        vibrate( 100 );
        bt_state=false;
        Intent intent1 = new Intent( this, BtPairA.class );
        intent1.putExtra("BT_STATE",bt_state);
        startActivity( intent1 );
    }
    public void classic_clicked(View view)
    {
        vibrate( 100 );
        bt_state=true;
        Intent intent2 = new Intent( this, BtPairA.class );
        intent2.putExtra("BT_STATE",bt_state);
        startActivity( intent2 );
    }
    public static void vibrate(int duration)
    {
        if (vibrate.hasVibrator()) {
            vibrate.vibrate( VibrationEffect.createOneShot( duration,2 ) );
        }
    }

}
