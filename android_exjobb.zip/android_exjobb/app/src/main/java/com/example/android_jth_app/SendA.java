package com.example.android_jth_app;


import android.annotation.SuppressLint;

import android.bluetooth.BluetoothGattCharacteristic;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


import java.io.File;

import java.io.FileOutputStream;

import java.io.OutputStreamWriter;

import androidx.appcompat.app.AppCompatActivity;

import static java.util.Arrays.copyOfRange;

public class SendA extends AppCompatActivity {
    public static Handler mhandler;
    public StringBuilder sb1 = new StringBuilder();
    public static TextView terminalv, title_termv;
    public static ScrollView scrollView;
    public static boolean bt_state2, autosend;
    public static byte[] mByteArr = new byte[55000];
    public volatile static boolean SENDING;
    public volatile static boolean READING;
    public int k = 0;
    public static String txtfile;
    public static double divider_d = 509.0;//509.0
    public static int divider_i = 509, sends = 0;
    public ToggleButton tgl_button;
    public static ToneGenerator toneG;

    @SuppressLint("HandlerLeak")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainActivity.vibrate(1000);
        setContentView(R.layout.activity_test);
        terminalv = (TextView) findViewById(R.id.terminal);
        title_termv = (TextView) findViewById(R.id.title_term);
        bt_state2 = getIntent().getExtras().getBoolean("BT_STATE2");
        scrollView = (ScrollView) findViewById(R.id.scrolling);
        tgl_button = (ToggleButton) findViewById(R.id.toggleButton);
        toneG = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        Log.d("LOG", "CONNECTED ACTIVITY");
        sends = 0;
        autosend = false;
        for (int i = 0; i < mByteArr.length; i++) {
            if (i >= 50000) {
                mByteArr[i] = (byte) 255;
            } else {
                mByteArr[i] = (byte) (k++ % 255);
            }
        }
        mhandler = new Handler() {
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 1:
                        sb1.append(msg.obj);
                        terminalv.setText(sb1);
                        scrollView.fullScroll(View.FOCUS_DOWN);
                        if (autosend) {
                            writeToFile(terminalv.getText().toString(), getApplicationContext());
                        }

                }
            }
        };
    }

    public void return_clicked(View view) throws InterruptedException {
        MainActivity.vibrate(100);
        onBackPressed();

    }

    public void status_clicked(View view) {
        MainActivity.vibrate(100);
        terminalv.setText("\nSTATUS...\n");
        if (bt_state2) {
            ThreadS.myThread.write("status_req".getBytes());
        } else {
            try {
                BtPairA.bleTX.setValue("status_req");
                BtPairA.bleGatt.writeCharacteristic(BtPairA.bleTX);

                while (!BtPairA.timeToRead) ;
                BtPairA.bleGatt.readCharacteristic(BtPairA.bleRX);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    public void auto_clicked(View view) {
        if (tgl_button.isChecked()) {
            autosend = true;
            Log.d("LOG", "auto_clicked: ON");
        } else {
            Log.d("LOG", "auto_clicked: OFF");
            autosend = false;
        }
    }

    public void start_clicked(View view) {
        MainActivity.vibrate(100);
        if (autosend) {
            try {
                Thread.sleep(5000);//ÖKA FÖR ATT HINNA UT UR KAMMARE
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            toneG.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
        }
        sends=0;
        send(bt_state2);
    }

    public static void send(boolean bt_state2) {
        //terminalv.setText("\nSENDING...\n");
        title_termv.setText("SENDING...");
        if (bt_state2) {
            Log.d("LOG", "CLASSIC SEND");
            ThreadS.myThread.write(mByteArr);

        } else {
            Log.d("LOG", "BLE SEND");
            try {
                SENDING = true;
                BtPairA.bleTX.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        int temp = (int) Math.ceil(mByteArr.length / divider_d);
                        byte[][] slices = new byte[temp][divider_i];
                        for (int i = 0; i < temp - 1; i++) {
                            slices[i] = copyOfRange(mByteArr, i * divider_i, i * divider_i + divider_i);
                        }
                        slices[temp - 1] = copyOfRange(mByteArr, (temp - 1) * divider_i, mByteArr.length);
                        BtPairA.timeToRead = false;
                        for (int i = 0; i < temp; i++) {
                            SENDING = true;
                            BtPairA.bleTX.setValue(slices[i]);
                            BtPairA.bleGatt.writeCharacteristic(BtPairA.bleTX);
                            while (SENDING) ;
                            SENDING = true;
                        }

                        while (!BtPairA.timeToRead) {
                            //Log.d("LOG", "Waiting");
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        };
                        READING = true;
                        BtPairA.bleGatt.readCharacteristic(BtPairA.bleRX);
                        //Log.d("LOG", "run: RREADCHAR");
                        while (READING);
                    }
                }).start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        title_termv.setText("TERMINAL");
    }

    public static void writeToFile(String data, Context context) {
        toneG.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200);
        //Log.d("LOG", "writeToFile: ");
        if (bt_state2) {
            txtfile = "bredr_log.txt";
        } else {
            txtfile = "ble_log.txt";
        }
        try {
            File file = new File("/sdcard/" + txtfile);
            file.createNewFile();
            if (file.exists()) {
                file.delete();

                file = new File("/sdcard/" + txtfile);
                file.createNewFile();
            }
            FileOutputStream fOut = new FileOutputStream(file);
            OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
            myOutWriter.append(data);
            myOutWriter.close();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (autosend && sends < 20)
        {
            sends++;
            send(bt_state2);
        }
        else{
            Log.d( "LOG", "Autosend complete!" );
            toneG.startTone( ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
            Toast.makeText(context, "AUTOSEND COMPLETE",Toast.LENGTH_SHORT).show();
        }
        //REDO SEND TO AUTO
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        sends=0;
        try{
            BtPairA.unpairDevice( BtPairA.socket.getRemoteDevice() );
        }catch( Exception e)
        {
            e.printStackTrace();
        }
        try{

            BtPairA.socket.close();
            BtPairA.socket = null;

        }catch(Exception e)
        {
            e.printStackTrace();
        }
        try{
            BtPairA.unpairDevice( BtPairA.bleGatt.getDevice());

        }catch(Exception e)
        {
            e.printStackTrace();
        }
        try{
            BtPairA.close();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        finish();
    }
}
